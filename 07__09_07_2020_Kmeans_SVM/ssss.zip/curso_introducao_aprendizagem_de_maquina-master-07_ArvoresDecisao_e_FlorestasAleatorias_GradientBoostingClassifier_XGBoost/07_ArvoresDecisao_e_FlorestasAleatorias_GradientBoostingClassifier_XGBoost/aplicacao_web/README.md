# para subir aplicação web com bokeh
bokeh serve --show appweb.py

